//
//  ViewController.swift
//  LocalNotification
//
//  Created by steve on 2016-07-30.
//  Copyright © 2016 steve. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //MARK: ViewController LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    
    
    @IBAction func buttonTapped(sender: AnyObject) {
        scheduleNotification()
        postNotification()
    }
    
    private func scheduleNotification() {
        let notification = UILocalNotification()
        let calendar = NSCalendar.currentCalendar()
        let seconds = NSDateComponents()
        seconds.second = 10
        let date = calendar.dateByAddingComponents(seconds, toDate: NSDate(), options:NSCalendarOptions.MatchStrictly)
        notification.fireDate = date
        
        notification.alertBody = "Merry Christmas!"
        
        notification.alertTitle = "Inappropriate Title"
        notification.alertAction = "Go Bananas!"
        notification.applicationIconBadgeNumber = 1
        notification.soundName = "sound.caf"
        UIApplication.sharedApplication().scheduleLocalNotification(notification)
    }
    
    private func postNotification() {
        NSNotificationCenter.defaultCenter().postNotificationName("ExampleNotification", object: nil)
    }
}

